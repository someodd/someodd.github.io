# Core themes

* Gopher history
* Simplicity as Freedom
* Community over Commerce
* Enshittification
