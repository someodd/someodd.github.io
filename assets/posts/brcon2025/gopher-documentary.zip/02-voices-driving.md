# The voices driving it

* Cory Doctorow: author & digital-rights activist
* Gopher pioneers: Mark P. McCahill, Bob Alberti, Paul Lindner
* Leading smallnet builders & community luminaries -- note: bitreich brought up a lot
