# Timeline & milestones

* Research & interviews: what's done, what's upcoming
* Production: Q1 2026 at latest, hopefully
* Post & festivals: Q2 2026 at latest, hopefully. Rough cut, festival submissions, community screenings (like at Roxxy!)

