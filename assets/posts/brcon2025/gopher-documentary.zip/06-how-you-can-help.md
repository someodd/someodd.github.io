# How you can help

* Spread the word: social tags: #smallnetdoc
* Host a local screening at your hackerspace or library
* Torrent/seed for prosperity
* Share your experiences about gopher, smallnet
* Send us pieces of gopher history, memorabilia, etc.
