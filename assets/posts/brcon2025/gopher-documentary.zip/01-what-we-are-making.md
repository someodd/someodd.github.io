# What we're making

* Documentary on the "smallnet" revival
* Why Gopher and lean protocols matter today
* Exploring tech culture, community, and resistance to "enshittification"
